from login_form import Ui_MainWindow
from database import DataBase
import sys
from PySide6.QtWidgets import QApplication, QMessageBox, QMainWindow


class Login_Form(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.db = DataBase()

        self.btn_exit.clicked.connect(self.close)
        self.btn_login.clicked.connect(self.on_login)
        self.btn_guest.clicked.connect(self.guest)

        self.line_login.returnPressed.connect(self.on_login)
        self.line_password.returnPressed.connect(self.on_login)

        self.line_login.setText("admin")
        self.line_password.setText("admin")


    def on_login(self):
        login = self.line_login.text()
        password = self.line_password.text()

    

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Введите логин или пароль!")
            return
            

        user = self.db.get_user(login, password)
        
        if user:
            print(f"Успешный вход: {user['full_name']} ({user['role']})")
        
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль!")
            return

    def guest(self):
        print("Вход как гость")
        guest = {
            'id': '0',
            'role': 'Гость',
            'full_name': 'Гость',
            'login': '',
            'password': ''
        }
        




        

if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = Login_Form()
    window.show()

    sys.exit(app.exec())



    
