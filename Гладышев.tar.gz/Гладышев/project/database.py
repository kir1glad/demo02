import pymysql

class DataBase():
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        try:
            self.connection = pymysql.connect(
                host='localhost',
                database='demo_db',
                user='phpmyadmin',
                password='phpmyadmin',
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor
            )
        except Exception as e:
            print(f"Ошибка подключения к бд: {e}")
            self.connection = None

    def get_user(self, login, password):
        try:
            with self.connection.cursor() as cursor:
                sql = "SELECT id, role, full_name FROM users WHERE login=%s AND password=%s"
                cursor.execute(sql, (login, password))
                result = cursor.fetchone()
                return result
        except Exception as e:
            print(f"Ошибка получения пользователя: {e}")

    def close(self):
        if self.connection:
            self.close()
            self.connection = None
